package com.nrose.lenden.lenden

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
