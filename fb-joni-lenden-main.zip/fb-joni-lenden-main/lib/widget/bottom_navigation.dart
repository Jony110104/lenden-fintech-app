import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:lenden/screen/homeScreen.dart';
import 'package:lenden/screen/transactionScreen.dart';

class BottomNavigation extends StatefulWidget {
  final int passIndex;
  const BottomNavigation({super.key, this.passIndex = 1});

  @override
  State<BottomNavigation> createState() => _BottomNavigationState();
}

class _BottomNavigationState extends State<BottomNavigation> {
  int currentIndex = 0;

  setBottomBarIndex(index) {
    setState(() {
      currentIndex = index;
    });
  }

  void initState() {
    super.initState();
    setState(() {
      currentIndex = widget.passIndex;
    });
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;

    return Stack(
      children: [
        Positioned(
          bottom: 12,
          left: 0,
          child: SizedBox(
            width: size.width * 1.0,
            child: Center(
              child: GestureDetector(
                child: Container(
                  decoration:
                      BoxDecoration(borderRadius: BorderRadius.circular(100)),
                  child: Image.asset(
                    'assets/icons/scan.png',
                    height: 100,
                    width: 100,
                  ),
                ),
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 0,
          left: 0,
          child: SizedBox(
            width: size.width,
            height: 60,
            child: Stack(
              children: [
                CustomPaint(
                  size: Size(size.width, 80),
                  painter: BNBCustomPainter(),
                ),
                SizedBox(
                  width: size.width,
                  height: 60,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      GestureDetector(
                        onTap: () {
                          // setBottomBarIndex(1);
                          // if(widget.passIndex == 2){
                          //   Navigator.pop(context);
                          // }
                          if(widget.passIndex == 2){
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HomeScreen(),
                              ));
                          }
                        },
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SvgPicture.asset(
                              currentIndex == 1
                                  ? 'assets/icons/home_fill.svg'
                                  : 'assets/icons/home_line.svg',
                              width: 24,
                              height: 24,
                            ),
                            Text(
                              'Home',
                              style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  color: currentIndex == 1
                                      ? Colors.black
                                      : Colors.black54),
                            )
                          ],
                        ),
                      ),
                      Container(
                        width: size.width * 0.20,
                      ),
                      GestureDetector(
                        onTap: () {
                          // setBottomBarIndex(2);
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => TransactionScreen(),
                              ));
                        },
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SvgPicture.asset(
                              currentIndex == 1
                                  ? 'assets/icons/activity_line.svg'
                                  : 'assets/icons/activity_fill.svg',
                              width: 24,
                              height: 24,
                            ),
                            Text(
                              'Transactions',
                              style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  color: currentIndex == 2
                                      ? Colors.black
                                      : Colors.black54),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class BNBCustomPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = new Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    Path path = Path();
    path.moveTo(0, 0);
    path.quadraticBezierTo(size.width * 0.20, 0, size.width * 0.35, 0);
    path.quadraticBezierTo(size.width * 0.40, 0, size.width * 0.43, 20);
    path.arcToPoint(Offset(size.width * 0.57, 20),
        radius: const Radius.circular(38.0), clockwise: false);
    path.quadraticBezierTo(size.width * 0.60, 0, size.width * 0.65, 0);
    path.quadraticBezierTo(size.width * 0.80, 0, size.width, 0);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.lineTo(0, 20);
    canvas.drawShadow(path, Colors.black, 5, true);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return false;
  }
}
