import 'package:flutter/material.dart';
import 'package:lenden/config/colors.dart';

class Offers extends StatelessWidget {
  const Offers({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8)
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Offers',
                  style: TextStyle(
                      color: MyColor.textNormal,
                      fontSize: 14,
                      fontWeight: FontWeight.w500
                  ),
                ),
                Text(
                  'See All',
                  style: TextStyle(
                      color: MyColor.textSecondary,
                      fontSize: 12,
                      fontWeight: FontWeight.w400
                  ),
                )
              ],
            ),
            Container(
              height: 1,
              margin: const EdgeInsets.only(top: 8),
              decoration: const BoxDecoration(
                  color: Colors.black12
              ),
            ),
            const SizedBox(height: 16,),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.symmetric(vertical: 2),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 1,
                            color: Colors.black12
                        ),
                        borderRadius: BorderRadius.circular(8)
                    ),
                    child: Column(
                      children: [
                        ClipRRect(
                          borderRadius: const BorderRadius.only(topLeft: Radius.circular(8),topRight: Radius.circular(8),),
                          child: Image.asset(
                            'assets/images/free_consultaion.png',
                            width: 148,
                            height: 103,
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Free Consultation',
                                style: TextStyle(
                                    color: MyColor.textNormal,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14
                                ),
                              ),
                              Text(
                                'Medico',
                                style: TextStyle(
                                    color: MyColor.textNormal,
                                    fontSize: 12
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(width: 14,),
                  Container(
                    margin: const EdgeInsets.symmetric(vertical: 2),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 1,
                            color: Colors.black12
                        ),
                        borderRadius: BorderRadius.circular(8)
                    ),
                    child: Column(
                      children: [
                        ClipRRect(
                          borderRadius: const BorderRadius.only(topLeft: Radius.circular(8),topRight: Radius.circular(8),),
                          child: Image.asset(
                            'assets/images/bdt_100_cashback.png',
                            width: 148,
                            height: 103,
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Free Consultation',
                                style: TextStyle(
                                    color: MyColor.textNormal,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14
                                ),
                              ),
                              Text(
                                'Medico',
                                style: TextStyle(
                                    color: MyColor.textNormal,
                                    fontSize: 12
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      );
  }
}
